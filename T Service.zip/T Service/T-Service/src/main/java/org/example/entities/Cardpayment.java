package org.example.entities;

public class Cardpayment {

}
