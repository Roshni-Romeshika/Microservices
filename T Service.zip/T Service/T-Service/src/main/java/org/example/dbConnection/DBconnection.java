package org.example.dbConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBconnection {

	private static DBconnection database=null;
	private Connection connection=null;
	
	private DBconnection() {
		try {
			setConnection();
		}catch(ClassNotFoundException ex) {
			Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE, null, ex);
		}catch(SQLException ex) {
			Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE,null,ex);
		}
	}
	
	public static DBconnection getInstance() {
		if(database==null) {
			synchronized(DBconnection.class) {
				if(database==null) {
					database=new DBconnection();
				}
			}
		}
		
		return database;
	}
	
	public void setConnection()throws ClassNotFoundException,SQLException{
		
		String url="jdbc:mysql://localhost:3306/traindb";
		String user="root";
		String pass="";
		
		Class.forName("com.mysql.jdbc.Driver");
		
		connection=DriverManager.getConnection(url,user,pass);
	}
	
	public Connection getconnection() {
		if(connection!=null) {
			return connection;
		}
		else
			return null;
	}
	
}
