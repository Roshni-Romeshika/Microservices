package org.example.entities;

public class User {
	int uid;
	int pid;
	String NIC;
	String email;
	int phonenumber;
	public User(int uid, int pid, String nIC, String email, int phonenumber) {
		super();
		this.uid = uid;
		this.pid = pid;
		NIC = nIC;
		this.email = email;
		this.phonenumber = phonenumber;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getNIC() {
		return NIC;
	}
	public void setNIC(String nIC) {
		NIC = nIC;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(int phonenumber) {
		this.phonenumber = phonenumber;
	}
	
	

}
