package org.example.datalayerImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.example.dbConnection.DBconnection;
import org.example.entities.Train;

public class TrainInfoImple {
	

	public static List<Train> displayStarts() {
        String sql = null;
        ResultSet result = null;
        List<Train> trains = null;
        Train train = null;
	
        
	
	try {
		
		DBconnection dbcon = DBconnection.getInstance();
	    Connection con = dbcon.getconnection();
	    Statement st = con.createStatement();
	    
	    sql = "SELECT tid,amount,train from Train";
	    
	    result = st.executeQuery(sql);
	    
	    trains = new ArrayList<>();
	    
	    while (result.next()) {
	    	train = new Train(result.getInt("tid"),result.getDouble("amount"),result.getString("train"));
	    	train.setTid(result.getInt("tid"));
	    	train.setAmount(result.getDouble("amount"));
	    	train.setTrain(result.getString("trains"));
	    	
	    	
	    	trains.add(train);
	    	
	    }
	    
	}
	
	catch(SQLException ex){
		Logger.getLogger(TrainInfoImple.class.getName()).log(Level.SEVERE, null, ex);
	}
	
	finally {
		return trains;
	}
}
}
