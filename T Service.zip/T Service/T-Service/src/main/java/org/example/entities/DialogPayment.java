package org.example.entities;

public class DialogPayment {
	
	int pid;
	double amount;
	int mobilenumber;
	int pinnumber;
	public DialogPayment(int pid, double amount, int mobilenumber, int pinnumber) {
		super();
		this.pid = pid;
		this.amount = amount;
		this.mobilenumber = mobilenumber;
		this.pinnumber = pinnumber;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(int mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public int getPinnumber() {
		return pinnumber;
	}
	public void setPinnumber(int pinnumber) {
		this.pinnumber = pinnumber;
	}
	
	

}
