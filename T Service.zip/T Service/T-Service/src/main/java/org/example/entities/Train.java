package org.example.entities;

public class Train {
	
	private int tid ;
	private String train;
	private double amount;
	
	public Train(int tid, double amount, String train) {
		super();
		this.tid = tid;
		this.train = train;
		this.amount = amount;// TODO Auto-generated constructor stub
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTrain() {
		return train;
	}
	public void setTrain(String train) {
		this.train = train;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	

}
