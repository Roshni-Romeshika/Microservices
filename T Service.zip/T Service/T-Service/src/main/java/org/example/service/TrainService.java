package org.example.service;

import java.awt.PageAttributes.MediaType;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.OPTIONS;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.example.datalayerImpl.TrainInfoImple;
import org.example.entities.Train;
import org.wso2.msf4j.Request;




public class TrainService {
	
	
	List <Train> trains;

    @GET
    @Path("/get-train")
    @Produces(MediaType.APPLICATION_JSON)
    public List<Train> getTrain(@Context Request request, @Context Response response) {
    	response.setHeader("Access-Control-Allow-Origin", request.getHeader("Origin"));
        System.out.println("GET Train");
        List<Train> trainList = TrainInfoImple.displayStarts();
        
        return trainList;
        
    }
    
    @POST
    public Train addTrain(Train newTrain) {
		trains.add(newTrain);
		for(Train t:trains) {
			if(t.getTid() == newTrain.getTid())
				return t;
		}	
		throw new NotFoundException();
	}
    
    @PUT
    @Path("/")
    public void put() {
        // TODO: Implementation for HTTP PUT request
        System.out.println("PUT invoked");
    }
    
    @Path("{id}")
		@DELETE
		@Produces(MediaType.APPLICATION_JSON)
		public Train deleteTrain(@PathParam("id") String train) {
			for(Train t : trains) {
				if(t.getTid() == Train) {
					trains.remove(t);
					return t;
				}
			}
			throw new NotFoundException();
			}
		
		@Path("/get-train")
		@OPTIONS
		@Produces(MediaType.APPLICATION_JSON)
		public javax.ws.rs.core.Response getResponse(@Context Request request) {
			javax.ws.rs.core.Response response = javax.ws.rs.core.Response.status(200)
					.header("Access-Control-Allow-Origin", request.getHeader("Origin"))
					.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE")
					.header("Access-Control-Allow-Headers", "content-type")
					.build();
			
			return response;
			
		}


}
