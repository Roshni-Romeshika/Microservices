import React, {Component} from 'react';
import Homepic from './Homepic';
import logo from "./employee.jpg"
import {NavLink} from "react-router-dom";


class TrainHome extends Component{
    render() {
        return (
            <div >

                <div className='Homepic' >
                    <div>
                        <h1><center> <font color="white">Welcome to Train Ticketing Service</font></center></h1>
                    </div>
                </div>

                <div className='div1' width="100%" height="100%" >

                    <div className="form-style-5">
                        <form>
                            <legend><span className="number"></span> If you are Government Employee ?</legend><br/><br/>

                            <NavLink to="/gemployee" exact>

                                <button type="submit" className="btn btn-primary">Yes</button>
                            </NavLink>

                            <NavLink to="/Paymentmethods" exact>

                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <button type="submit" className="btn btn-primary">No</button><br/><br/>
                            </NavLink>
                        </form>
                        <img src={logo} className="rounded" width={500} height={300}/>
                    </div>
                </div>
                <div className="blockquote-footer">
                    <p>WE MAKE YOUR LIFE SIMPLE AND FAST</p>
                </div>

            </div>

        );
    }
}
export default TrainHome;