import React, {Component} from 'react';
import Homepic from './Homepic';
import {NavLink} from "react-router-dom";






class TrainHome extends Component{
    render() {
        return (
            <div >

                <div className='Homepic' >
                    <div>
                    <h1><center> <font color="white">Welcome to Train Ticketing Service</font></center></h1>
                    </div>
                </div>

                <div className='div1' width="100%" height="100%" >

                    <h4><font color="white"><center>TICKET BOOKING</center></font></h4>


                        <div className="form-style-5">
                            <form>
                                <fieldset>
                                    <legend><span className="number">1</span> Train Info</legend>

                                            <label htmlFor="job">Train</label>
                                            <select id="job" name="field4">
                                                <optgroup label="Intercity Train">
                                                    <option value="1">Colombo-Kandy</option>
                                                    <option value="2">Colombo-Galle</option>
                                                    <option value="3">Colombo-Jaffna</option>
                                                </optgroup>
                                                <optgroup label="Normal Train">
                                                    <option value="4">Panadura-Maradana</option>
                                                    <option value="5">Kaluthara-Kotuwa</option>
                                                    <option value="6">Negombo-Kotuwa</option>

                                                </optgroup>
                                            </select>
                                </fieldset>
                                <fieldset>
                                    <legend><span className="number">2</span> Number of Tickets Info</legend>
                                    <textarea name="number" placeholder="Number of Tickets to be booked"></textarea>
                                </fieldset>
                                <NavLink to="/employee" exact>

                                    <button type="submit" className="btn btn-primary">Next</button>
                                </NavLink>

                            </form>
                            <Homepic/>
                    </div>
                 </div>
                <div className="blockquote-footer">
                    <p>WE MAKE YOUR LIFE SIMPLE AND FAST</p>
                </div>
            </div>
        );
    }
}
export default TrainHome;