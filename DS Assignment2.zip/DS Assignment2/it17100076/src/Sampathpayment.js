import React,{Component} from "react"
import Homepic from './Homepic';
import logo from "./Sampath.jpg"
import {NavLink} from "react-router-dom";


class Sampathpayment extends Component {
    render() {
        return (
            <div>

                <div className='Homepic' >
                    <div>
                        <h1><center> <font color="white">Welcome to Train Ticketing Service</font></center></h1>
                    </div>

                    <div className='div1' width="100%" height="100%" >

                        <h4><font color="white"><center>PAYMENT PROCESS IS ON GOING</center></font></h4>


                        <div className="form-style-5">
                            <img src={logo} className="rounded" width={400} height={200}/>
                            <form>
                                <fieldset>
                                    <legend><span className="number"></span>Sampath Bank Card Info</legend>

                                    <label htmlFor="job">Credit Card Number</label>
                                    <input type="text" placeholder="Please enter your valid Card Number"/>

                                    <label htmlFor="job">Name of Card Holder</label>
                                    <input type="text" placeholder="Please enter your name"/>

                                    <label htmlFor="job">CVC Number</label>
                                    <input type="text" />

                                    <label htmlFor="job">Amount</label>
                                    <input type="text" placeholder="Rs. "/>

                                </fieldset>

                                <NavLink to="/" exact>

                                    <button type="submit" className="btn btn-primary">Reserve Your Train</button><br/><br/>
                                </NavLink>

                            </form>


                        </div>
                    </div>
                    <div className="blockquote-footer">
                        <p>WE MAKE YOUR LIFE SIMPLE AND FAST</p>
                    </div>
                    </div>

                    </div>


        );

    }
}

export  default Sampathpayment;