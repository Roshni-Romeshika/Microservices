import React,{Component} from "react";
import Homepic from './Homepic';
import {NavLink} from "react-router-dom";

class Paymentmethods extends Component{
    render() {
        return (
            <div>
                <div className='Homepic' >
                    <div>
                        <h1><center> <font color="white">Welcome to Train Ticketing Service</font></center></h1>
                    </div>
                </div>

                <div className='div1' width="100%" height="100%" >

                    <h4><font color="white"><center>GET READY TO YOUR PAYMENT PROCEDURE</center></font></h4>


                    <div className="form-style-5">
                        <form>

                            <legend><span className="number"></span> Available Payment Methods</legend><br/><br/>

                            <NavLink to="/sampathpayment" exact>

                                <button type="submit" className="btn btn-primary">Sampath Bank Payment Gateway</button>
                            </NavLink>

                            <NavLink to="/dialogpayment" exact>

                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <button type="submit" className="btn btn-primary">Dialog Payment</button><br/><br/>
                            </NavLink>

                        </form>
                        <Homepic/>

                    </div>
                </div>
                <div className="blockquote-footer">
                    <p>WE MAKE YOUR LIFE SIMPLE AND FAST</p>
                </div>

            </div>

        );
    }
}

export default Paymentmethods;