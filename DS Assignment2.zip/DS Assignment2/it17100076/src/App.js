import React, {Component} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter,Switch,Route,Link} from "react-router-dom";
import './App.css';
import TrainHome from "./TrainHome";
import Gemployee from "./Gemployee"
import Paymentmethods from "./Paymentmethods"
import Sampathpayment from "./Sampathpayment"
import Dialogpayment from "./Dialogpayment"
import Employee from "./Employee"

class App extends Component {
  render() {
    return(

        <BrowserRouter>
        <div>
            <Switch>
                    <Route path="/" component={TrainHome} exact/>
                    <Route path="/employee" component={Employee} exact/>
                    <Route path="/gemployee" component={Gemployee} exact/>
                    <Route path="/paymentmethods" component={Paymentmethods} exact/>
                    <Route path="/sampathpayment" component={Sampathpayment} exact/>
                    <Route path="/dialogpayment" component={Dialogpayment} exact/>
            </Switch>
        </div>
        </BrowserRouter>


    );
  }
}

export default App;
