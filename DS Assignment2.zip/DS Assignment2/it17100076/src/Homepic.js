import React, {Component} from 'react';
import TrainPic from './TrainHomePic.jpg';

class Homepic extends Component{
    render() {
        return(
            <div>
                <img src={TrainPic} class="img-fluid"  width='100%'   />
            </div>
        );
    }

}
export default Homepic;