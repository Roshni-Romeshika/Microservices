import React, {Component} from 'react';
import Homepic from './Homepic';
import logo from "./employee.jpg"
import {NavLink} from "react-router-dom";


class TrainHome extends Component{
    render() {
        return (
            <div >

                <div className='Homepic' >
                    <div>
                        <h1><center> <font color="white">Welcome to Train Ticketing Service</font></center></h1>
                    </div>
                </div>

                <div className='div1' width="100%" height="100%" >

                    <div className="form-style-5">
                        <form>
                            <legend><span className="number"></span> We will be processed you a discount</legend><br/><br/>

                            <fieldset>
                                <legend><span className="number"></span> NIC Number</legend>
                                <textarea name="text" placeholder="Please Enter Your NIC Number"></textarea>
                            </fieldset>

                            <NavLink to="/Paymentmethods" exact>

                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <button type="submit" className="btn btn-primary">Payment Procedure</button><br/><br/>
                            </NavLink>
                        </form>
                        <img src={logo} className="rounded" width={500} height={300}/>
                    </div>
                </div>



                <div className="blockquote-footer">
                    <p>WE MAKE YOUR LIFE SIMPLE AND FAST</p>
                </div>

            </div>

        );
    }
}
export default TrainHome;